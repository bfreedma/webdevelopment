from django.apps import AppConfig


class CookbookConfig(AppConfig):
    name = 'cookbook'
